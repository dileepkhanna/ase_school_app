export enum CircularType {
  EXAM = 'EXAM',
  EVENT = 'EVENT',
  PTM = 'PTM',
  HOLIDAY = 'HOLIDAY',
  TRANSPORT = 'TRANSPORT',
  GENERAL = 'GENERAL',
}
