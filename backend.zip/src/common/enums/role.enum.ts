export enum Role {
  PRINCIPAL = 'PRINCIPAL',
  TEACHER = 'TEACHER',
  STUDENT = 'STUDENT',

  // Internal (ASE Admin Panel)
  ASE_ADMIN = 'ASE_ADMIN',
}
