export enum PaymentStatus {
  PENDING = 'PENDING',
  DONE = 'DONE',
}
